'''
Created on Oct 27, 2014

@author: asmith039
'''
import pycurl
import json
from StringIO import StringIO
import re
import datetime

#from getthesprintdates import currentsprint


pageTemplate = '''
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta content="text/html; charset=ISO-8859-1"
 http-equiv="content-type">
  <title>PwC Bi-Weekly Report</title>
  <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {{packages:["table"]}});
      google.setOnLoadCallback(drawTable);

      function drawTable() {{
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Key');
        data.addColumn('string', 'Summary');
        data.addColumn('string', 'Description');
        data.addColumn('string', 'Sprint');
        data.addColumn('string', 'Components');
        data.addColumn('string', 'Resolution');
        data.addColumn('string', 'Outcome');
        data.addRows([
          {0}
        ]);
        
        var data2 = new google.visualization.DataTable();
        data2.addColumn('string', 'Key');
        data2.addColumn('string', 'Summary');
        data2.addColumn('string', 'Description');
        data2.addColumn('string', 'Components');
        data2.addRows([
          {1}
        ]);
        
        var data3 = new google.visualization.DataTable();
        data3.addColumn('string', 'Key');
        data3.addColumn('string', 'Summary');
        data3.addColumn('string', 'Description');
        data3.addColumn('string', 'Components');
        data3.addRows([
          {2}
        ]);
        
        var data4 = new google.visualization.DataTable();
        data4.addColumn('string', 'Key');
        data4.addColumn('string', 'Summary');
        data4.addColumn('string', 'Description');
        data4.addColumn('string', 'Sprint');
        data4.addColumn('string', 'Outcome');
        data4.addRows([
          {3}
        ]);
        
        var data5 = new google.visualization.DataTable();
        data5.addColumn('string', 'Key');
        data5.addColumn('string', 'Summary');
        data5.addColumn('string', 'Description');
        data5.addColumn('string', 'Components');
        data5.addRows([
          {4}
        ]);
        
        var table = new google.visualization.Table(document.getElementById('table_div')); table.draw(data);
        
        var table2 = new google.visualization.Table(document.getElementById('table2_div')); table2.draw(data2);
        
        var table3 = new google.visualization.Table(document.getElementById('table3_div')); table3.draw(data3);
        
        var table4 = new google.visualization.Table(document.getElementById('table4_div')); table4.draw(data4);
        
        var table5 = new google.visualization.Table(document.getElementById('table5_div')); table5.draw(data5);

        table.draw(data, {{showRowNumber: false}});
      }}
    </script>
</head>
<body>
<table>
<tr>
<th colspan="4">PwC Bi-Weekly Status Report: Perceptive Reach</th>
</tr>
<tr>
<td>Project Name:</td><td><a href="http://vacloud.us/groups/558/">Perceptive Reach</a></td><td>VA PM/COR:</td><td>Clint Latimer</td>
</tr>
<tr>
<td>Vendor Name:</td><td>PwC</td><td>Program Manager:</td><td><a href="mailto:paul.bradley@us.pwc.com" class="myclass">
Paul Bradley</a></td>
</tr>
<tr>
<td>Contract#:</td><td>VA118-14-C-0046</td><td>Project Manager:</td><td><a href="mailto:monica.mohler@us.pwc.com" class="myclass">Monica Mohler</a></td>
</tr>
<tr>
<td colspan="2">GitHub Repository: <br> <a href="https://github.com/VHAINNOVATIONS/PerceptiveReach">VHAINNOVATIONS PerceptiveReach</a></td><td colspan="2">Reporting Period: {5}</td>
</tr>
<tr>
<th colspan="4">Contract Overview </th>
</tr>
<tr>
<td colspan="4">The Perceptive Reach development and field pilot proposes to combine technology, outreach and clinical support to realize a clinically based data-driven early intervention and treatment solution aimed at suicide prevention. PwC will deliver a solution for analyzing multiple and integrated data sets with cutting-edge data analytic techniques and visualizations to identify at-risk individuals and populations and provide proactive and secure notifications of these results to Veteran support services. The Perceptive Reach project proposes to expand the capabilities of the Suicide Data Repository to include new interfaces to clinical data sources, integrated data analytics capabilities, a surveillance dashboard, and secure messaging "-" thus enhancing SDR capabilities to include upstream suicide intervention.</td>
</tr>
</table>
<center><h4>Key Activities Completed for this Reporting Period:</h4></center>
<div id="table_div"></div>
<br><center><h4>Meetings for this Reporting Period:</h4></center>
<div id="table4_div"></div>
<br><center><h4>Deliverables Submitted for this Reporting Period:</h4></center>
<div id="table3_div"></div>
<br><center><h4>Open Risks for this Reporting Period:</h4></center>
<div id="table2_div"></div>
<br><center><h4>Closed Risks for this Reporting Period:</h4></center>
<div id="table5_div"></div>
<br>
<h3>Last update: {6} </h3>
</body>
</html>''' 

def get_sprint_number_dates():
    #get today's date
    todaysdate = datetime.date.today()
    #number of days in the sprint
    numdays = 11
    #dictionary of sprint days
    jirasprintnumbers = {'Sprint 2': '44', 'Sprint 3': '45', 'Sprint 4': '57','Sprint 5':'58', 'Sprint 6': '59', 'Sprint 7': '60'}
    sprintrangeofdays = {'Sprint 2':'10/20/2014 - 10/31/2014', 'Sprint 3' : '11/03/2014 - 11/14/2014', 'Sprint 4': '11/17/14 - 11/28/2014','Sprint 5':'12/1/14 - 12/11/14', 'Sprint 6':'12/12/14 - 12/23/14', 'Sprint 7':'1/5/15 - 1/19/15'}
    sprintenddays = {'Sprint 2': '2014, 10, 31', 'Sprint 3': '2014, 11, 14','Sprint 4': '2014, 11, 28','Sprint 5':'2014, 12, 11','Sprint 6': '2014, 12, 23', 'Sprint 7': '2015, 01, 15'}
    #loop through the dict of sprints
    for k, v in sprintenddays.iteritems():
        #convert string to datetime
        v = datetime.datetime.strptime(v , "%Y, %m, %d" )
        #convert datetime to date
        v = v.date()
        #make a list of dates in the sprint based on the end date and number of days in the sprint
        date_list = [v - datetime.timedelta(days=x) for x in range(0,numdays)]
        if todaysdate in date_list:
            print 'Today is in', k
            print 'Bi-weekly reporting period is', sprintrangeofdays[k]
            global biweeklydaterange
            biweeklydaterange = sprintrangeofdays[k]
            currentsprint = jirasprintnumbers[k]
            print currentsprint

    
def main():
    #get today's date
    todaysdate = datetime.date.today()
    #number of days in the sprint
    numdays = 11
    #dictionary of sprint days
    jirasprintnumbers = {'Sprint 2': '44', 'Sprint 3': '45', 'Sprint 4': '57','Sprint 5':'58', 'Sprint 6': '59', 'Sprint 7': '60', 'Sprint 8':'61','Sprint 9':'62','Sprint 10':'63'}
    sprintrangeofdays = {'Sprint 2':'10/20/2014 - 10/31/2014', 'Sprint 3' : '11/03/2014 - 11/14/2014', 'Sprint 4': '11/17/14 - 11/28/2014','Sprint 5':'12/1/14 - 12/11/14', 'Sprint 6':'12/12/14 - 12/23/14', 'Sprint 7':'1/5/15 - 1/15/15','Sprint 8':'1/16/15 - 1/29/15','Sprint 9': '1/30/15 - 2/12/15','Sprint 10':'2/13/15 - 2/26/15'}
    sprintenddays = {'Sprint 2': '2014, 10, 31', 'Sprint 3': '2014, 11, 14','Sprint 4': '2014, 11, 28','Sprint 5':'2014, 12, 11','Sprint 6': '2014, 12, 23', 'Sprint 7': '2015, 01, 15','Sprint 8':'2015, 01, 29','Sprint 9':'2015, 02, 12','Sprint 10':'2015, 02, 26'}
    #loop through the dict of sprints
    for k, v in sprintenddays.iteritems():
        #convert string to datetime
        v = datetime.datetime.strptime(v , "%Y, %m, %d" )
        #convert datetime to date
        v = v.date()
        #make a list of dates in the sprint based on the end date and number of days in the sprint
        date_list = [v - datetime.timedelta(days=x) for x in range(0,numdays)]
        if todaysdate in date_list:
            print 'Today is in', k
            print 'Bi-weekly reporting period is', sprintrangeofdays[k]
            global biweeklydaterange
            biweeklydaterange = sprintrangeofdays[k]
            currentsprint = jirasprintnumbers[k]
            print currentsprint
    #get_values_from_entry()
    bufferugh = StringIO()
    #setup curl
    c = pycurl.Curl()
    #project = PR AND Sprint is not EMPTY AND  Resolution = Fixed OR Sprint is not EMPTY AND Resolution = Done
    #project = PR AND Sprint is not EMPTY AND  Resolution = Fixed and component != Meetings OR Sprint is not EMPTY AND Resolution = Done and component != Meetings
    #c.setopt(c.URL, 'https://opensourceehr.atlassian.net/rest/api/2/search?jql=project%20%3D%20PR%20AND%20Sprint%20is%20not%20EMPTY%20AND%20%20Resolution%20%3D%20Fixed%20OR%20Sprint%20is%20not%20EMPTY%20AND%20Resolution%20%3D%20Done&maxResults=1000')
    #project = PR AND component = "Bi Weekly Report" and resolution = fixed or component = "Bi Weekly Report" and resolution = done
    #project = PR and Sprint = 45 and component = "Bi Weekly Report" and resolution = Fixed or Sprint = 45 and component = "Bi Weekly Report" and resolution = done or Sprint = 45 and component = "Bi Weekly Report" and resolution = Done
    #activites in progres - urljoined = "".join (['https://opensourceehr.atlassian.net/rest/api/2/search?jql=project%20%3D%20pr%20and%20sprint%20%3D%20',currentsprint,'%20and%20component%20%3D%20%22Bi%20Weekly%20Report%22'])
    #urljoined = "".join (['https://opensourceehr.atlassian.net/rest/api/2/search?jql=project%20%3D%20PR%20and%20Sprint%20%3D%20',currentsprint,'%20and%20component%20%3D%20"Bi%20Weekly%20Report"%20and%20resolution%20%3D%20Fixed%20or%20Sprint%20%3D%20',currentsprint,'%20and%20component%20%3D%20"Bi%20Weekly%20Report"%20and%20resolution%20%3D%20done%20or%20Sprint%20%3D%20',currentsprint,'%20and%20component%20%3D%20"Bi%20Weekly%20Report"%20and%20resolution%20%3D%20Done'])
    urljoined = "".join(['https://opensourceehr.atlassian.net/rest/api/2/search?jql=project%20%3D%20PR%20and%20Sprint%20%3D%20',currentsprint,'%20AND%20component%20%3D%20"Bi%20Weekly%20Report"%20and%20component%20!%3D%20"External%20Meetings"'])
    c.setopt(pycurl.URL,urljoined)
    #maxresults issue
    c.setopt(pycurl.HTTPHEADER, ['Accept: application/json'])
    c.setopt(pycurl.VERBOSE, 0)
    c.setopt(pycurl.USERPWD, 'andrew.smith:punkz99')
    c.setopt(pycurl.WRITEDATA, bufferugh)
    c.perform()
    c.close()
    body = bufferugh.getvalue()
    #use json to load the body into a dictionary
    data = json.loads(body)
    #print data
    LineInTableBig = []
    searchthemall = data['issues']
    print 'Gathering Key Activities'
    
    for entry in searchthemall:
        #issue key
        Key = entry['key']
        print Key
        #print Key
        #issue summary
        Summary = entry['fields']['summary']
        #print Summary
        #replace the ' with \'
        #strsummary = str(Summary)
        #"didn't".replace("'", "\'")
        Summary =  Summary.replace("'","")
        #issue description
        Descriptionfoundit = entry['fields']['description']
        ##print Descriptionfoundit
        #Descriptionfoundit.encode('utf-8')
        if Descriptionfoundit is None:
            Description = str(Descriptionfoundit)            
        else:
            Description = str(Descriptionfoundit.encode('utf-8'))
            Description = Description.decode('utf-8')
            Description = Description.encode('ascii','ignore')
            ##print Description
            #print lalala
        ##print Description
        Description =  Description.replace("'","")
        #issue sprint number
        #print entry['fields']['customfield_10007']
        listofsprints = []
        findthesprint = entry['fields']['customfield_10007']
        #print findthesprint
        for p in entry['fields']['customfield_10007']:
            #print 'found it'
            listofsprints.append(p)
        #print listofsprints
        #what to do if a task is assigned to multiple Sprints
        if len(listofsprints) > 1:
            #print 'This task is in two sprints'
            #print listofsprints[0]
            #print listofsprints[1]
            SprintV1 = listofsprints[0]
            peanut = str(SprintV1)
            walnut = peanut.split(",")
            spicy = walnut[2]
            dasprint = spicy.strip('name=')
            SprintV1Editted = dasprint
            #print SprintV1Editted
            SprintV2 = listofsprints[1]
            peanut = str(SprintV2)
            walnut = peanut.split(",")
            spicy = walnut[2]
            dasprint = spicy.strip('name=')
            SprintV2Editted = dasprint
            #print SprintV2Editted
            Sprint = "".join ([SprintV1Editted,',',SprintV2Editted])
            #print Sprint
        else:
            #print listofsprints[0]
            peanut = str(findthesprint)
            walnut = peanut.split(",")
            spicy = walnut[2]
            dasprint = spicy.strip('name=')
            Sprint = dasprint
            #print Sprint
        """    
        peanut = str(findthesprint)
        #print peanut
        walnut = peanut.split(",")
        spicy = walnut[2]
        dasprint = spicy.strip('name=')
        Sprint = dasprint
        #print Sprint
        """
        #issue components
        #print entry['fields']['components']
        #ugmug = entry['fields']['components']
        #print ugmug
        listofcomponents = []
        for r in entry['fields']['components']:
            #print r['name']
            compots = r['name']
            listofcomponents.append(compots)
        #print listofcomponents
        #print len(listofcomponents)
        if len(listofcomponents) > 1:
            #print listofcomponents[1]
            Components = listofcomponents[1]
        else:
            #print listofcomponents[0]
            Components = listofcomponents[0]
        """    
        #print ugmug
        apple = str(ugmug)
        #print apple
        grape = apple.split(":")
        #print grape
        grapes = str(grape)
        strawberry = grapes.split(",")
        #print strawberry
        #print strawberry[4]
        #ugh why is this broken
        yoyomo = strawberry[4].strip('" u')
        #ohgoshitworks
        Components = yoyomo.strip("'")
        #print Components     
        """
        #issue resolved value
        #print entry['fields']['resolution']
        chugchug = entry['fields']['resolution']
        if str(chugchug) == 'None':
            Resolution = 'In Progress'
        else:
            coke = str(chugchug)
            #print coke
            dietcoke = coke.split(",")
            cokezero = str(dietcoke[2])
            vanillacoke = cokezero.split(":")
            #gotit
            Resolution =  vanillacoke[1].strip(" u'")
        #print Resolution
        #issue custom outcome field or last entry in the work log
        Outcome1 = entry['fields']['customfield_10500']
        #print Outcome1
        #print Outcome1.encode("utf-8",errors='replace')
        #Outcome = Outcome1.encode("utf-8",errors='i')
        #print Outcome1.decode("utf-8")
        Outcome = str(Outcome1)
        Outcome =  Outcome.replace("'","")
        Outcome = Outcome.replace('"',"")
        #Outcome = Outcome2.decode("utf-8")
        #add outcome to the lineintable
        LineInTable = "".join (['[',"'",Key,"'",',',"'",Summary,"'",',',"'",Description,"'",',',"'",Sprint,"'",',',"'",Components,"'",',',"'",Resolution,"'",',',"'",Outcome,"'",']',','])
        LineInTableBig.append(LineInTable)
        
        #get_values_from_entry()
    
    #get the Open Risks
    bufferugh = StringIO()
    #setup curl
    c = pycurl.Curl()
    #search project = PR and component = Risks
    #c.setopt(c.URL, 'https://opensourceehr.atlassian.net/rest/api/2/search?jql=project%20%3D%20PR%20and%20component%20%3D%20Risks')
    c.setopt(c.URL, 'https://opensourceehr.atlassian.net/rest/api/2/search?jql=project%20%3D%20PR%20and%20component%20%3D%20Risks%20and%20status%20%3D%20Open')
    #maxresults issue
    c.setopt(pycurl.HTTPHEADER, ['Accept: application/json'])
    c.setopt(pycurl.VERBOSE, 0)
    c.setopt(pycurl.USERPWD, 'andrew.smith:punkz99')
    c.setopt(pycurl.WRITEDATA, bufferugh)
    
    c.perform()
    c.close()
    body = bufferugh.getvalue()
    #use json to load the body into a dictionary
    riskdata = json.loads(body)
    #print riskdata
    RiskLineInTableBig = []
    alltherisks = riskdata['issues']
    #print "Gathering Open Risks"
    for entry in alltherisks:
        #print entry
        #issue key
        Key = entry['key']
        #print Key
        #issue summary
        Summary = entry['fields']['summary']
        #print Summary
        #replace the ' with \'
        #strsummary = str(Summary)
        #"didn't".replace("'", "\'")
        Summary =  Summary.replace("'","")
        #issue description
        Descriptionfoundit = entry['fields']['description']
        #Description = str(Descriptionfoundit)
        if Descriptionfoundit is None:
            Description = str(Descriptionfoundit)            
        else:
            Description = str(Descriptionfoundit.encode('utf-8'))
            Description = Description.decode('utf-8')
            Description = Description.encode('ascii','ignore')
            ##print Description
        Description =  Description.replace("'","")
        Description =  Description.replace('"','')
        ##print Description
        #issue sprint number
        #print entry['fields']['customfield_10007']
        findthesprint = entry['fields']['customfield_10007']
        #print findthesprint
        """
        peanut = str(findthesprint)
        #print peanut
        walnut = peanut.split(",")
        spicy = walnut[2]
        dasprint = spicy.strip('name=')
        Sprint = dasprint
        """
        Sprint = 'None'
        #print Sprint
        #issue components
        #print entry['fields']['components']
        #ugmug = entry['fields']['components']
        #print ugmug
        """
        apple = str(ugmug)
        #print apple
        grape = apple.split(":")
        #print grape
        grapes = str(grape)
        strawberry = grapes.split(",")
        #print strawberry
        yoyomo = strawberry[13].strip('" u')
        #ohgoshitworks
        Components = yoyomo.strip("'")
        """
        Components = 'Risk Issues'
        #print Components     
        #issue resolved value
        #print entry['fields']['resolution']
        chugchug = entry['fields']['resolution']
        #print chugchug
        Resolution = str(chugchug)
        """
        coke = str(chugchug)
        #print coke
        dietcoke = coke.split(",")
        cokezero = str(dietcoke[2])
        vanillacoke = cokezero.split(":")
        #gotit
        Resolution =  vanillacoke[1].strip(" u'")
        #print Resolution
        #issue custom outcome field or last entry in the work log
        Outcome1 = entry['fields']['customfield_10500']
        Outcome = str(Outcome1)
        """
        Outcome = 'None'
        #add outcome to the lineintable
        RiskLineInTable = "".join (['[',"'",Key,"'",',',"'",Summary,"'",',',"'",Description,"'",',',"'",Components,"'",']',','])
        RiskLineInTableBig.append(RiskLineInTable)
        #get_values_from_entry()
        #remove the sprint/resolution/outcome
    #print RiskLineInTableBig
    
    #get the closed risks
    bufferugh = StringIO()
    #setup curl
    c = pycurl.Curl()
    #search project = PR and component = Risks
    #c.setopt(c.URL, 'https://opensourceehr.atlassian.net/rest/api/2/search?jql=project%20%3D%20PR%20and%20component%20%3D%20Risks')
    c.setopt(c.URL, 'https://opensourceehr.atlassian.net/rest/api/2/search?jql=project%20%3D%20PR%20and%20component%20%3D%20Risks%20and%20status%20%3D%20Closed')
    #maxresults issue
    c.setopt(pycurl.HTTPHEADER, ['Accept: application/json'])
    c.setopt(pycurl.VERBOSE, 0)
    c.setopt(pycurl.USERPWD, 'andrew.smith:punkz99')
    c.setopt(pycurl.WRITEDATA, bufferugh)
    
    c.perform()
    c.close()
    body = bufferugh.getvalue()
    #use json to load the body into a dictionary
    riskdata = json.loads(body)
    #print riskdata
    RiskClosedLineInTableBig = []
    alltherisks = riskdata['issues']
    #print "Gathering Closed Risks"
    for entry in alltherisks:
        #print entry
        #issue key
        Key = entry['key']
        #print Key
        #issue summary
        Summary = entry['fields']['summary']
        #print Summary
        #replace the ' with \'
        #strsummary = str(Summary)
        #"didn't".replace("'", "\'")
        Summary =  Summary.replace("'","")
        #issue description
        Descriptionfoundit = entry['fields']['description']
        if Descriptionfoundit is None:
            Description = str(Descriptionfoundit)            
        else:
            Description = str(Descriptionfoundit.encode('utf-8'))
            Description = Description.decode('utf-8')
            Description = Description.encode('ascii','ignore')
            #print Description
        
        #Description = str(Descriptionfoundit)
        ##print Description
        Description =  Description.replace("'","")
        #issue sprint number
        #print entry['fields']['customfield_10007']
        findthesprint = entry['fields']['customfield_10007']
        #print findthesprint
        """
        peanut = str(findthesprint)
        #print peanut
        walnut = peanut.split(",")
        spicy = walnut[2]
        dasprint = spicy.strip('name=')
        Sprint = dasprint
        """
        Sprint = 'None'
        #print Sprint
        #issue components
        #print entry['fields']['components']
        #ugmug = entry['fields']['components']
        #print ugmug
        """
        apple = str(ugmug)
        #print apple
        grape = apple.split(":")
        #print grape
        grapes = str(grape)
        strawberry = grapes.split(",")
        #print strawberry
        yoyomo = strawberry[13].strip('" u')
        #ohgoshitworks
        Components = yoyomo.strip("'")
        """
        Components = 'Risk Issues'
        #print Components     
        #issue resolved value
        #print entry['fields']['resolution']
        chugchug = entry['fields']['resolution']
        #print chugchug
        Resolution = str(chugchug)
        """
        coke = str(chugchug)
        #print coke
        dietcoke = coke.split(",")
        cokezero = str(dietcoke[2])
        vanillacoke = cokezero.split(":")
        #gotit
        Resolution =  vanillacoke[1].strip(" u'")
        #print Resolution
        #issue custom outcome field or last entry in the work log
        Outcome1 = entry['fields']['customfield_10500']
        Outcome = str(Outcome1)
        """
        Outcome = 'None'
        #add outcome to the lineintable
        RiskClosedLineInTable = "".join (['[',"'",Key,"'",',',"'",Summary,"'",',',"'",Description,"'",',',"'",Components,"'",']',','])
        RiskClosedLineInTableBig.append(RiskClosedLineInTable)
        #get_values_from_entry()
        #remove the sprint/resolution/outcome
    #print RiskLineInTableBig
        
    #get the deliverables
    bufferugh = StringIO()
    #setup curl
    c = pycurl.Curl()
    #search project = PR and component = Deilverable
    c.setopt(pycurl.URL, 'https://opensourceehr.atlassian.net/rest/api/2/search?jql=project%20%3D%20PR%20and%20component%20%3D%20"Bi%20Weekly%20Deliverable"')
    #maxresults issue
    c.setopt(pycurl.HTTPHEADER, ['Accept: application/json'])
    c.setopt(pycurl.VERBOSE, 0)
    c.setopt(pycurl.USERPWD, 'andrew.smith:punkz99')
    c.setopt(pycurl.WRITEDATA, bufferugh)
    
 
    c.perform()
    c.close()
    body = bufferugh.getvalue()
    #use json to load the body into a dictionary
    deliverablesdata = json.loads(body)
    #print deliverablesdata
    deliverablesLineInTableBig = []
    allthedeliverables = deliverablesdata['issues']
    for entry in allthedeliverables:
        #print entry
        #issue key
        Key = entry['key']
        #print Key
        #issue summary
        Summary = entry['fields']['summary']
        #print Summary
        #replace the ' with \'
        #strsummary = str(Summary)
        #"didn't".replace("'", "\'")
        Summary =  Summary.replace("'","")
        #issue description
        #print entry['fields']['description']
        Descriptionfoundit = entry['fields']['description']
        #Description = str(Descriptionfoundit)
        if Descriptionfoundit is None:
            Description = str(Descriptionfoundit)            
        else:
            Description = str(Descriptionfoundit.encode('utf-8'))
            Description = Description.decode('utf-8')
            Description = Description.encode('ascii','ignore')
            #print Description
        ##print Description
        Description =  Description.replace("'","")
        #issue sprint number
        #print entry['fields']['customfield_10007']
        #findthesprint = entry['fields']['customfield_10007']
        #print findthesprint
        """
        peanut = str(findthesprint)
        #print peanut
        walnut = peanut.split(",")
        spicy = walnut[2]
        dasprint = spicy.strip('name=')
        Sprint = dasprint
        """
        #Sprint = 'None'
        #print Sprint
        #issue components
        #print entry['fields']['components']
        #ugmug = entry['fields']['components']
        #print ugmug
        """
        apple = str(ugmug)
        #print apple
        grape = apple.split(":")
        #print grape
        grapes = str(grape)
        strawberry = grapes.split(",")
        #print strawberry
        yoyomo = strawberry[13].strip('" u')
        #ohgoshitworks
        Components = yoyomo.strip("'")
        """
        Components = 'Deliverable'
        #print Components     
        #issue resolved value
        #print entry['fields']['resolution']
        #chugchug = entry['fields']['resolution']
        #print chugchug
        #Resolution = str(chugchug)
        """
        coke = str(chugchug)
        #print coke
        dietcoke = coke.split(",")
        cokezero = str(dietcoke[2])
        vanillacoke = cokezero.split(":")
        #gotit
        Resolution =  vanillacoke[1].strip(" u'")
        #print Resolution
        #issue custom outcome field or last entry in the work log
        Outcome1 = entry['fields']['customfield_10500']
        Outcome = str(Outcome1)
        """
        #Outcome = 'None'
        #add outcome to the lineintable
        deliverablesLineInTable = "".join (['[',"'",Key,"'",',',"'",Summary,"'",',',"'",Description,"'",',',"'",Components,"'",']',','])
        deliverablesLineInTableBig.append(deliverablesLineInTable)
        #get_values_from_entry()
        #remove the sprint/resolution/outcome
    #print deliverablesLineInTableBig  
    
    
    #get the meetings Project%20%3D%20PR%20and%20Sprint%20%3D%2044%20and%20component%20%3D%20"Bi%20Weekly%20Report"%20and%20sprint%20%3D%2044%20and%20component%20%3D%20Meetings
    bufferugh = StringIO()
    #setup curl
    c = pycurl.Curl()
    #search
    #project = PR AND Sprint = 44 and component = Meetings and assignee = mattrobinson and key != PR-360
    #add the join command here for the sprint number
    urljoined = "".join (['https://opensourceehr.atlassian.net/rest/api/2/search?jql=project%20%3D%20PR%20AND%20Sprint%20%3D%20',currentsprint,'%20and%20component%20%3D%20"External%20Meetings"'])
    c.setopt(pycurl.URL, urljoined)
    #maxresults issue
    c.setopt(pycurl.HTTPHEADER, ['Accept: application/json'])
    c.setopt(pycurl.VERBOSE, 0)
    c.setopt(pycurl.USERPWD, 'andrew.smith:punkz99')
    c.setopt(pycurl.WRITEDATA, bufferugh)
    
    c.perform()
    c.close()
    body = bufferugh.getvalue()
    #use json to load the body into a dictionary
    meetingsdata = json.loads(body)
    print 'Meetings'
    meetingsLineInTableBig = []
    allthemeetings = meetingsdata['issues']
    for entry in allthemeetings:
        #print entry
        #issue key
        Key = entry['key']
        #print Key
        #issue summary
        Summary = entry['fields']['summary']
        #print Summary
        #replace the ' with \'
        #strsummary = str(Summary)
        #"didn't".replace("'", "\'")
        Summary =  Summary.replace("'","")
        #issue description
        #print entry['fields']['description']
        Descriptionfoundit = entry['fields']['description']
        if Descriptionfoundit is None:
            Description = str(Descriptionfoundit)            
        else:
            Description = str(Descriptionfoundit.encode('utf-8'))
            Description = Description.decode('utf-8')
            Description = Description.encode('ascii','ignore')
            #print Description
        #Description = str(Descriptionfoundit)
        ##print Description
        Description =  Description.replace("'","")
        #issue sprint number
        #print entry['fields']['customfield_10007']
        findthesprint = entry['fields']['customfield_10007']
        #print findthesprint
        peanut = str(findthesprint)
        #print peanut
        walnut = peanut.split(",")
        spicy = walnut[2]
        dasprint = spicy.strip('name=')
        Sprint = str(dasprint)
        #Sprint = 'None'
        #print Sprint
        #issue components
        #print entry['fields']['components']
        #ugmug = entry['fields']['components']
        #print ugmug
        """
        apple = str(ugmug)
        #print apple
        grape = apple.split(":")
        #print grape
        grapes = str(grape)
        strawberry = grapes.split(",")
        #print strawberry
        yoyomo = strawberry[13].strip('" u')
        #ohgoshitworks
        Components = yoyomo.strip("'")
        """
        #Components = 'Deliverable'
        #print Components     
        #issue resolved value
        #print entry['fields']['resolution']
        #chugchug = entry['fields']['resolution']
        #print chugchug
        #Resolution = str(chugchug)
        """
        coke = str(chugchug)
        #print coke
        dietcoke = coke.split(",")
        cokezero = str(dietcoke[2])
        vanillacoke = cokezero.split(":")
        #gotit
        Resolution =  vanillacoke[1].strip(" u'")
        #print Resolution
        """
        #issue custom outcome field or last entry in the work log
        Outcome1 = entry['fields']['customfield_10500']
        #print Outcome1
        Outcome = str(Outcome1)
        Outcome =  Outcome.replace("'","")
        Outcome = Outcome.replace('"',"")
        #print Outcome

        #Outcome = 'None'
        #add outcome to the lineintable
        #(['[',"'",Key,"'",',',"'",Summary,"'",',',"'",Description,"'",',',"'",Sprint,"'",',',"'",Components,"'",',',"'",Resolution,"'",',',"'",Outcome,"'",']',','])
        meetingsLineInTable = "".join (['[',"'",Key,"'",',',"'",Summary,"'",',',"'",Description,"'",',',"'",Sprint,"'",',',"'",Outcome,"'",']',','])
        meetingsLineInTableBig.append(meetingsLineInTable)
        #print meetingsLineInTableBig
            
    
    
    
    #need to clean up some characters for this to work better
    #['{Key}','{Summary}','{Description}','{Sprint}','{Components}','{Outcome}'],
    #['PR-454','Dashboard Prototype Refactoring','None','Sprint 2','Development Tasks','Fixed','None'],   
    strLineInTableBig  = str(LineInTableBig)
    #remove the 3 leading chracters
    removethefirst3 = strLineInTableBig[3:]
    #get the len of the string and remove the last #
    howbigisbig = len(removethefirst3)
    x = howbigisbig - 2
    #print x
    #quick math and removing the last two characters
    oksonowitstrimmed = removethefirst3[0:x]
    #print oksonowitstrimmed
    #use some regex to remove stuff  
    line = oksonowitstrimmed
    line = re.sub('(".*?")', '', line.rstrip())
    #print(line)
    #now we just need to deal with the 's junk
    global jira_resolution_results_cleaned
    jira_resolution_results_cleaned = line
    print 'Tickets cleaneds'
    if bool(jira_resolution_results_cleaned) == False:
        jira_resolution_results_cleaned = str("['','','','','','',''],")
    print jira_resolution_results_cleaned
    
    #clean up the deliverabls
    strdeliverablesLineInTableBig = str(deliverablesLineInTableBig)
    #remove the 3 leading chracters
    deliverablesremovethefirst3 = strdeliverablesLineInTableBig[3:]
    #get the len of the string and remove the last #
    deliverableshowbigisbig = len(deliverablesremovethefirst3)
    deliverablesx = deliverableshowbigisbig - 2
    #print x
    #quick math and removing the last two characters
    deliverablesoksonowitstrimmed = deliverablesremovethefirst3[0:deliverablesx]
    #print oksonowitstrimmed
    #use some regex to remove stuff  
    deliverablesline = deliverablesoksonowitstrimmed
    deliverablesline = re.sub('(".*?")', '', deliverablesline.rstrip())
    #now we just need to deal with the 's junk
    global deliverables_jira_resolution_results_cleaned
    deliverables_jira_resolution_results_cleaned = deliverablesline
    print 'Cleaned deliverables'
    print deliverables_jira_resolution_results_cleaned
    
    #clean up the open risks
    strRiskLineInTableBig = str(RiskLineInTableBig)
    #print strRiskLineInTableBig
    #remove the 3 leading chracters
    Riskremovethefirst3 = strRiskLineInTableBig[3:]
    #get the len of the string and remove the last #
    Riskhowbigisbig = len(Riskremovethefirst3)
    Riskx = Riskhowbigisbig - 2
    #print x
    #quick math and removing the last two characters
    Riskoksonowitstrimmed = Riskremovethefirst3[0:Riskx]
    #print oksonowitstrimmed
    #use some regex to remove stuff  
    Riskline = Riskoksonowitstrimmed
    Riskline = re.sub('(".*?")', '', Riskline.rstrip())
    #print Riskline
    Riskline = re.sub('(\\\\)', '', Riskline.rstrip())
    Riskline = re.sub('rn', '', Riskline.rstrip())
    ### ', u, u" ###
    ### '\', u'
    Riskline = re.sub('\', u','',Riskline.rstrip())
    ### ', u"'
    Riskline = re.sub(', u"','',Riskline.rstrip())
    #print Riskline
    #now we just need to deal with the 's junk
    global Risk_jira_resolution_results_cleaned
    Risk_jira_resolution_results_cleaned = Riskline
    print 'Cleaned Open Risk'
    print Risk_jira_resolution_results_cleaned

    #clean up the closed risks
    strRiskClosedLineInTableBig = str(RiskClosedLineInTableBig)
    #remove the 3 leading chracters
    RiskClosedremovethefirst3 = strRiskClosedLineInTableBig[3:]
    #get the len of the string and remove the last #
    RiskClosedhowbigisbig = len(RiskClosedremovethefirst3)
    RiskClosedx = RiskClosedhowbigisbig - 2
    #print x
    #quick math and removing the last two characters
    RiskClosedoksonowitstrimmed = RiskClosedremovethefirst3[0:RiskClosedx]
    #print oksonowitstrimmed
    #use some regex to remove stuff  
    RiskClosedline = RiskClosedoksonowitstrimmed
    RiskClosedline = re.sub('(".*?")', '', RiskClosedline.rstrip())
    #now we just need to deal with the 's junk
    global Risk_Closed_jira_resolution_results_cleaned
    Risk_Closed_jira_resolution_results_cleaned = RiskClosedline
    print 'Cleaned CLosed Risk'
    print Risk_Closed_jira_resolution_results_cleaned    
    
    #clean up the meetings
    strmeetingsLineInTableBig = str(meetingsLineInTableBig)
    #print strmeetingsLineInTableBig
    #remove the 3 leading chracters
    meetingsremovethefirst3 = strmeetingsLineInTableBig[3:]
    #get the len of the string and remove the last #
    meetingshowbigisbig = len(meetingsremovethefirst3)
    meetingsx = meetingshowbigisbig - 2
    #print x
    #quick math and removing the last two characters
    meetingsoksonowitstrimmed = meetingsremovethefirst3[0:meetingsx]
    #print oksonowitstrimmed
    #use some regex to remove stuff  
    meetingsline = meetingsoksonowitstrimmed
    meetingsline = re.sub('(".*?")', '', meetingsline.rstrip())
    meetingsline = re.sub('(\\\\)', '', meetingsline.rstrip())
    #print meetingsline
    #now we just need to deal with the 's junk
    global meetings_jira_resolution_results_cleaned
    meetings_jira_resolution_results_cleaned= meetingsline
    print 'Cleaned Meetings'
    print meetings_jira_resolution_results_cleaned 
     
    #put the last update value on the page
    updatedate = datetime.datetime.now()
    #put the data into the html page template above
    contents = pageTemplate.format(jira_resolution_results_cleaned,Risk_jira_resolution_results_cleaned,deliverables_jira_resolution_results_cleaned,meetings_jira_resolution_results_cleaned,Risk_Closed_jira_resolution_results_cleaned,biweeklydaterange,updatedate)
    browseLocal(contents)



def strToFile(text, filename):
    output = open(filename,"w")
    output.write(text)
    output.close()

def browseLocal(webpageText, filename='chart.html'):
    '''Start your webbrowser on a local file containing the text
    with given filename.'''
    #import webbrowser, os.path
    strToFile(webpageText, filename)
    #webbrowser.open("file:///" + os.path.abspath(filename)) #elaborated for Mac

main()